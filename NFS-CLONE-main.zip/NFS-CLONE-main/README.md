# NFS-CLONE
Auto Facebook Account Cracker

Termux Commands

apt install git

git clone http://github.com/nfs-tech-bd/NFS-CLONE

cd NFS-CLONE

python2 NFS-CLONE.py

Contact Me For Username And Password

http://facebook.com/nafis.fuad.904

Enjoy... 🐸
